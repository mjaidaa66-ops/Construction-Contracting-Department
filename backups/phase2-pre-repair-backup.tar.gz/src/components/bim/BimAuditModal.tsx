import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Lock, ShieldCheck } from 'lucide-react';
import type { DrawingAnalysisReport, Language } from '../../types/bunyan';
import { Button, Input, Modal } from '../ui';

interface BimAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: DrawingAnalysisReport | null;
  lang: Language;
  onConfirmCalibrationLock: (referenceLengthM: number, measuredUnits: number) => void;
}

export const BimAuditModal: React.FC<BimAuditModalProps> = ({
  isOpen,
  onClose,
  report,
  lang,
  onConfirmCalibrationLock,
}) => {
  const [refMeters, setRefMeters] = useState(String(report?.calibration.referenceLengthM || 5.0));
  const [measuredUnits, setMeasuredUnits] = useState(String(report?.calibration.measuredUnits || 200));

  if (!isOpen || !report) return null;

  const scaleFactor =
    Number(measuredUnits) > 0 && Number(refMeters) > 0
      ? Number(refMeters) / (Number(measuredUnits) / 40)
      : 1.0;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      maxWidthClass="max-w-lg"
      title={lang === 'ar' ? 'تدقيق ومعايرة المخطط الهندسي قبل فتح BOQ' : 'Drawing Audit & Scale Calibration Lock'}
      subtitle={report.fileName}
      footer={
        <>
          <Button variant="outline" size="sm" onClick={onClose}>
            {lang === 'ar' ? 'إغلاق' : 'Close'}
          </Button>
          <Button
            variant="primary"
            size="sm"
            icon={report.boqUnlocked ? <CheckCircle2 className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            onClick={() => {
              onConfirmCalibrationLock(Number(refMeters) || 5, Number(measuredUnits) || 200);
              onClose();
            }}
          >
            {lang === 'ar' ? 'تثبيت المقياس وفتح BOQ النهائي' : 'Lock Scale & Unlock 5D BOQ'}
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3 p-4 rounded-lg bg-[var(--bg-surface-subtle)] border border-[var(--border-hairline)] text-xs">
          <div>
            <div className="text-[var(--text-muted)]">{lang === 'ar' ? 'اسم الملف' : 'Source File'}</div>
            <div className="font-semibold text-[var(--text-primary)] truncate mt-0.5">{report.fileName}</div>
          </div>
          <div>
            <div className="text-[var(--text-muted)]">{lang === 'ar' ? 'شارة التحقق' : 'Verification Badge'}</div>
            <div className="font-mono font-bold text-[#B4863C] flex items-center gap-1 mt-0.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{report.badge}</span>
            </div>
          </div>
          <div>
            <div className="text-[var(--text-muted)]">{lang === 'ar' ? 'نوع المصدر' : 'Source Type'}</div>
            <div className="font-mono uppercase text-[var(--text-primary)] mt-0.5">{report.sourceType}</div>
          </div>
          <div>
            <div className="text-[var(--text-muted)]">{lang === 'ar' ? 'العناصر المستخرجة' : 'Extracted Elements'}</div>
            <div className="font-mono tabular-nums font-bold text-[var(--text-primary)] mt-0.5">{report.elementCount}</div>
          </div>
        </div>

        {report.warnings.length > 0 && (
          <div className="space-y-2">
            {report.warnings.map((w, i) => (
              <div
                key={i}
                className="flex items-start gap-2 text-xs text-amber-700 dark:text-amber-300 bg-amber-500/10 border border-amber-500/20 rounded-lg p-3"
              >
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{w}</span>
              </div>
            ))}
          </div>
        )}

        <div className="space-y-3 text-xs">
          <div className="font-semibold text-[var(--text-primary)]">
            {lang === 'ar'
              ? 'تأكيد معامل المقياس المرجعي (BimCalibrationData)'
              : 'Confirm Reference Span Calibration (BimCalibrationData)'}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input
              label={lang === 'ar' ? 'الطول الحقيقي المرجعي (م)' : 'Known Reference Length (m)'}
              type="number"
              step="0.1"
              min={0.1}
              value={refMeters}
              onChange={(e) => setRefMeters(e.target.value)}
              className="font-mono tabular-nums"
            />
            <Input
              label={lang === 'ar' ? 'الوحدات المقاسة على الرسم' : 'Measured Drawing Units'}
              type="number"
              step="1"
              min={1}
              value={measuredUnits}
              onChange={(e) => setMeasuredUnits(e.target.value)}
              className="font-mono tabular-nums"
            />
          </div>
          <div className="text-[11px] font-mono text-[var(--text-muted)]">
            Calculated Scale Factor:{' '}
            <span className="font-bold text-[var(--text-primary)]">{scaleFactor.toFixed(4)}</span>
          </div>
        </div>
      </div>
    </Modal>
  );
};
