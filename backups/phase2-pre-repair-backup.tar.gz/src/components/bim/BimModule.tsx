import React, { useRef, useState } from 'react';
import {
  CheckCircle2,
  FileUp,
  Lock,
  Maximize2,
  Minimize2,
  ShieldAlert,
  ShieldCheck,
  Unlock,
} from 'lucide-react';
import type {
  BimCameraPreset,
  BimDiscipline,
  BimElement,
  BimRenderMode,
  BimSectionMode,
  DrawingAnalysisReport,
  Language,
  Project,
} from '../../types/bunyan';
import { formatAED } from '../../utils/i18n';
import { parseIfcFile } from '../../utils/ifcParser';
import { parseCadOrPdfDrawing } from '../../utils/cadPdfParser';
import { Button, Card, StatusIndicator, useToast } from '../ui';
import { BimAuditModal } from './BimAuditModal';
import { BimModelTree } from './BimModelTree';
import { BimPropertiesPanel } from './BimPropertiesPanel';
import { BimViewer3D } from './BimViewer3D';

interface BimModuleProps {
  project: Project;
  lang: Language;
  onUpdateProject: (p: Project) => void;
  onJumpToTakeoff?: (measurementId: string) => void;
}

export const BimModule: React.FC<BimModuleProps> = ({
  project,
  lang,
  onUpdateProject,
  onJumpToTakeoff,
}) => {
  const { pushToast } = useToast();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const elements = project.bimElements || [];
  const [selectedId, setSelectedId] = useState<string | null>(elements[0]?.id || null);
  const [hiddenDisciplines, setHiddenDisciplines] = useState<Set<BimDiscipline>>(new Set());
  const [cameraPreset, setCameraPreset] = useState<BimCameraPreset>('iso');
  const [renderMode, setRenderMode] = useState<BimRenderMode>('pbr');
  const [sectionMode, setSectionMode] = useState<BimSectionMode>('none');
  const [sectionOffset, setSectionOffset] = useState<number>(6);
  const [auditOpen, setAuditOpen] = useState(false);
  const [focus3d, setFocus3d] = useState(false);

  const [analysisReport, setAnalysisReport] = useState<DrawingAnalysisReport>({
    id: 'rep-seed',
    fileName: `${project.code}_Sharjah_Villa_Model.ifc`,
    sourceType: 'ifc',
    verificationStatus: 'verified',
    badge: 'BIM VERIFIED',
    confidenceScore: 98,
    elementCount: elements.length,
    warnings: [],
    calibration: {
      isCalibrated: true,
      referenceLengthM: 16.0,
      measuredUnits: 640,
      scaleFactor: 1.0,
      lockedAt: '2026-02-01T10:00:00Z',
    },
    analyzedAt: '2026-02-01T10:00:00Z',
    boqUnlocked: true,
  });

  const selectedElement: BimElement | null =
    elements.find((e) => e.id === selectedId) || null;

  const totalBimCost = elements.reduce((acc, el) => acc + el.estimatedCost, 0);
  const totalConcreteVol = elements
    .filter((e) => e.boqCategory === 'concrete')
    .reduce((acc, e) => acc + e.volumeM3, 0);
  const totalNetWallArea = elements
    .filter((e) => e.category === 'wall')
    .reduce((acc, e) => acc + e.netAreaM2, 0);

  const handleToggleDiscipline = (disc: BimDiscipline) => {
    setHiddenDisciplines((prev) => {
      const next = new Set(prev);
      if (next.has(disc)) next.delete(disc);
      else next.add(disc);
      return next;
    });
  };

  const handleUploadDrawing = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const lower = file.name.toLowerCase();

    if (lower.endsWith('.ifc')) {
      const text = await file.text();
      const res = parseIfcFile(text, file.name);
      onUpdateProject({ ...project, bimElements: res.elements });
      setAnalysisReport(res.report);
      setSelectedId(res.elements[0]?.id || null);
      pushToast(
        lang === 'ar'
          ? `تم استيراد نموذج IFC (${res.elements.length} عنصر)`
          : `Imported IFC model (${res.elements.length} elements)`,
        'success'
      );
    } else {
      const text = lower.endsWith('.dxf') ? await file.text() : undefined;
      const res = parseCadOrPdfDrawing(file.name, text);
      onUpdateProject({ ...project, bimElements: res.elements });
      setAnalysisReport(res.report);
      setSelectedId(res.elements[0]?.id || null);
      setAuditOpen(true);
    }
    e.target.value = '';
  };

  const handleConfirmCalibrationLock = (refM: number, measuredUnits: number) => {
    const scaleFactor = measuredUnits > 0 ? refM / (measuredUnits / 40) : 1.0;
    setAnalysisReport((prev) => ({
      ...prev,
      verificationStatus: 'verified',
      badge: 'BIM VERIFIED',
      boqUnlocked: true,
      warnings: [],
      calibration: {
        isCalibrated: true,
        referenceLengthM: refM,
        measuredUnits,
        scaleFactor,
        lockedAt: new Date().toISOString(),
      },
    }));
    pushToast(
      lang === 'ar' ? 'تم تثبيت المقياس وتفعيل جدول الكميات 5D' : 'Scale locked & 5D BOQ unlocked',
      'success'
    );
  };

  return (
    <div className="space-y-4">
      {/* BIM Toolbar & Verification Audit Banner */}
      <Card className="p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <StatusIndicator
            tone={analysisReport.boqUnlocked ? 'success' : 'warning'}
            label={analysisReport.badge}
          />
          <span className="text-[var(--text-muted)]" aria-hidden="true">·</span>
          <span className="text-[var(--text-secondary)] truncate max-w-[220px]">
            {analysisReport.fileName}
          </span>
          <span className="text-[var(--text-muted)]" aria-hidden="true">·</span>
          <span className="font-mono tabular-nums text-[var(--text-secondary)]">
            {lang === 'ar' ? 'الخرسانة:' : 'RC Vol:'} {totalConcreteVol.toFixed(1)} m³
          </span>
          <span className="text-[var(--text-muted)]" aria-hidden="true">·</span>
          <span className="font-mono tabular-nums text-[var(--text-secondary)]">
            {lang === 'ar' ? 'صافي المباني:' : 'Net Walls:'} {totalNetWallArea.toFixed(1)} m²
          </span>
          <span className="text-[var(--text-muted)]" aria-hidden="true">·</span>
          <span dir="ltr" className="font-mono tabular-nums font-bold text-[#B4863C]">
            {analysisReport.boqUnlocked
              ? formatAED(totalBimCost, lang)
              : lang === 'ar' ? 'BOQ مقفل للمعايرة' : 'BOQ Locked'}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <Button
            variant="outline"
            size="sm"
            icon={focus3d ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            onClick={() => setFocus3d((v) => !v)}
          >
            {focus3d
              ? lang === 'ar'
                ? 'عرض الألواح الثلاثة'
                : '3-Panel View'
              : lang === 'ar'
              ? 'تكبير العارض 3D'
              : 'Expand 3D'}
          </Button>

          <Button
            variant="outline"
            size="sm"
            icon={
              analysisReport.boqUnlocked ? (
                <Unlock className="w-3.5 h-3.5 text-emerald-500" />
              ) : (
                <Lock className="w-3.5 h-3.5 text-amber-500" />
              )
            }
            onClick={() => setAuditOpen(true)}
          >
            {lang === 'ar' ? 'تدقيق المقياس' : 'Calibration Audit'}
          </Button>

          <input
            ref={fileInputRef}
            type="file"
            accept=".ifc,.dxf,.dwg,.pdf,.png,.jpg,.jpeg"
            onChange={handleUploadDrawing}
            className="hidden"
          />
          <Button
            variant="primary"
            size="sm"
            icon={<FileUp className="w-3.5 h-3.5" />}
            onClick={() => fileInputRef.current?.click()}
          >
            {lang === 'ar' ? 'استيراد IFC / DXF / PDF' : 'Import IFC / DXF / PDF'}
          </Button>
        </div>
      </Card>

      {/* 3-Column 5D BIM Workbench: Tree + 3D Viewport + Properties (or Focused 3D) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
        {!focus3d && (
          <div className="xl:col-span-3">
            <BimModelTree
              elements={elements}
              selectedId={selectedId}
              hiddenDisciplines={hiddenDisciplines}
              onSelectElement={setSelectedId}
              onToggleDiscipline={handleToggleDiscipline}
              lang={lang}
            />
          </div>
        )}

        <div className={focus3d ? 'xl:col-span-9' : 'xl:col-span-6'}>
          <BimViewer3D
            elements={elements}
            selectedId={selectedId}
            hiddenDisciplines={hiddenDisciplines}
            cameraPreset={cameraPreset}
            renderMode={renderMode}
            sectionMode={sectionMode}
            sectionOffset={sectionOffset}
            onSelectElement={setSelectedId}
            onChangeCameraPreset={setCameraPreset}
            onChangeRenderMode={setRenderMode}
            onChangeSectionMode={setSectionMode}
            onChangeSectionOffset={setSectionOffset}
            lang={lang}
          />
        </div>

        <div className="xl:col-span-3">
          <BimPropertiesPanel
            element={selectedElement}
            lang={lang}
            onJumpToTakeoff={onJumpToTakeoff}
          />
        </div>
      </div>

      {analysisReport.boqUnlocked && (
        <Card className="p-4 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-medium">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>
              {lang === 'ar'
                ? 'النموذج ثلاثي الأبعاد معتمد ومعاير — جميع الكميات الصافية والتكاليف مرتبطة بنظام المقايسات 5D.'
                : '3D BIM model verified and calibrated — all net quantities & void deductions are linked to 5D BOQ.'}
            </span>
          </div>
          <span dir="ltr" className="font-mono tabular-nums font-bold text-[var(--text-primary)]">
            {formatAED(totalBimCost, lang)}
          </span>
        </Card>
      )}

      <BimAuditModal
        isOpen={auditOpen}
        onClose={() => setAuditOpen(false)}
        report={analysisReport}
        lang={lang}
        onConfirmCalibrationLock={handleConfirmCalibrationLock}
      />
    </div>
  );
};
