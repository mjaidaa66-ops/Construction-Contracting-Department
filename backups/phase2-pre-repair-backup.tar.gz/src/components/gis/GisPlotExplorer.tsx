import React, { useMemo, useState } from 'react';
import { CheckCircle2, Compass, Layers, MapPin, Ruler, Search } from 'lucide-react';
import type { Language, Project } from '../../types/bunyan';
import { Card, CardHeader, Input } from '../ui';

interface GisPlotExplorerProps {
  project: Project;
  projects?: Project[];
  lang: Language;
  onUpdateProject: (p: Project) => void;
  onSelectProject?: (id: string) => void;
}

export const GisPlotExplorer: React.FC<GisPlotExplorerProps> = ({
  project,
  projects = [],
  lang,
  onUpdateProject,
  onSelectProject,
}) => {
  const { gisData } = project;
  const [showSetbacks, setShowSetbacks] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [plotSearch, setPlotSearch] = useState('');

  const isAr = lang === 'ar';

  const matchingPlots = useMemo(() => {
    const q = plotSearch.trim().toLowerCase();
    if (!q) return projects.slice(0, 8);
    return projects
      .filter(
        (p) =>
          p.gisData.plotNumber.toLowerCase().includes(q) ||
          p.gisData.sectorName.toLowerCase().includes(q) ||
          p.code.toLowerCase().includes(q) ||
          p.name.toLowerCase().includes(q)
      )
      .slice(0, 10);
  }, [projects, plotSearch]);

  const pts = gisData.boundaryPoints.length >= 3
    ? gisData.boundaryPoints
    : [
        { x: 0, y: 0, label: 'P1' },
        { x: 30, y: 0, label: 'P2' },
        { x: 30, y: 30, label: 'P3' },
        { x: 0, y: 30, label: 'P4' },
      ];

  const minX = Math.min(...pts.map((p) => p.x));
  const maxX = Math.max(...pts.map((p) => p.x));
  const minY = Math.min(...pts.map((p) => p.y));
  const maxY = Math.max(...pts.map((p) => p.y));

  const plotW = Math.max(1, maxX - minX);
  const plotH = Math.max(1, maxY - minY);

  const svgW = 780;
  const svgH = 520;
  const pad = 74;
  const scale = Math.min((svgW - pad * 2) / plotW, (svgH - pad * 2) / plotH);

  const toSvg = (x: number, y: number) => ({
    sx: pad + (x - minX) * scale + ((svgW - pad * 2) - plotW * scale) / 2,
    sy: pad + (y - minY) * scale + ((svgH - pad * 2) - plotH * scale) / 2,
  });

  const polyStr = pts
    .map((p) => {
      const { sx, sy } = toSvg(p.x, p.y);
      return `${sx},${sy}`;
    })
    .join(' ');

  const bx1 = minX + gisData.setbacks.sideLeft;
  const bx2 = maxX - gisData.setbacks.sideRight;
  const by1 = minY + gisData.setbacks.front;
  const by2 = maxY - gisData.setbacks.rear;
  const buildableAreaSqM = Math.max(0, (bx2 - bx1) * (by2 - by1));
  const coveragePct = Math.min(100, (buildableAreaSqM / Math.max(1, gisData.plotAreaSqM)) * 100);

  const bTL = toSvg(bx1, by1);
  const bBR = toSvg(bx2, by2);

  const handleSetbackChange = (field: keyof typeof gisData.setbacks, val: number) => {
    onUpdateProject({
      ...project,
      gisData: {
        ...gisData,
        setbacks: {
          ...gisData.setbacks,
          [field]: Math.max(0, val),
        },
      },
    });
  };

  return (
    <div className="space-y-5">
      {/* Search & Quick Sharjah Plot Bar */}
      {projects.length > 0 && onSelectProject && (
        <Card padded className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="w-full md:w-80">
            <Input
              value={plotSearch}
              onChange={(e) => setPlotSearch(e.target.value)}
              startIcon={<Search className="w-3.5 h-3.5" />}
              placeholder={isAr ? 'ابحث برقم القطعة أو المنطقة (الرحمانية، مويلح...)' : 'Search plot number or Sharjah sector...'}
            />
          </div>
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            {matchingPlots.slice(0, 5).map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => onSelectProject(p.id)}
                className={`px-2.5 py-1.5 rounded-lg border font-mono text-[11px] font-semibold cursor-pointer bunyan-transition ${
                  p.id === project.id
                    ? 'border-[#B4863C] bg-[#B4863C] text-white'
                    : 'border-[var(--border-hairline)] bg-[var(--bg-surface-subtle)] text-[var(--text-secondary)] hover:border-[#B4863C]'
                }`}
              >
                {p.gisData.plotNumber} · {p.gisData.sectorName}
              </button>
            ))}
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        {/* Dominant GIS Cadastral Viewport */}
        <Card className="xl:col-span-8 flex flex-col overflow-hidden">
          <CardHeader
            icon={<Compass className="w-4 h-4" />}
            title={
              isAr
                ? `مخطط الحدود المساحية GIS — قطعة ${gisData.plotNumber}`
                : `GIS Cadastral Plot Boundary — Plot ${gisData.plotNumber}`
            }
            subtitle={`${gisData.sectorName} · ${gisData.zoning}`}
            action={
              <div className="flex items-center gap-1.5 text-xs">
                {[
                  { active: showSetbacks, toggle: () => setShowSetbacks(!showSetbacks), label: isAr ? 'الارتدادات' : 'Setbacks' },
                  { active: showDimensions, toggle: () => setShowDimensions(!showDimensions), label: isAr ? 'الأبعاد' : 'Dimensions' },
                  { active: showGrid, toggle: () => setShowGrid(!showGrid), label: isAr ? 'الشبكة' : 'Grid' },
                ].map((btn, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={btn.toggle}
                    className={`px-2.5 py-1 rounded-md border text-[11px] font-semibold cursor-pointer bunyan-transition ${
                      btn.active
                        ? 'border-[#B4863C] bg-[#B4863C]/12 text-[#B4863C] dark:text-[#C99A49]'
                        : 'border-[var(--border-hairline)] text-[var(--text-muted)]'
                    }`}
                  >
                    {btn.label}
                  </button>
                ))}
              </div>
            }
          />

          <div className="bg-[#08101F] p-4 flex-1 flex items-center justify-center min-h-[520px]">
            <svg viewBox={`0 0 ${svgW} ${svgH}`} className="w-full max-h-[540px]">
              <defs>
                <pattern id="gisGrid" width="32" height="32" patternUnits="userSpaceOnUse">
                  <path d="M 32 0 L 0 0 0 32" fill="none" stroke="rgba(148,163,184,0.12)" strokeWidth="1" />
                </pattern>
              </defs>
              {showGrid && <rect width={svgW} height={svgH} fill="url(#gisGrid)" />}

              {/* Road Frontage Indicator */}
              <rect x={toSvg(minX, minY).sx} y={toSvg(minX, minY).sy - 36} width={plotW * scale} height="22" fill="rgba(51,65,85,0.5)" rx="3" />
              <text
                x={toSvg(minX + plotW / 2, minY).sx}
                y={toSvg(minX, minY).sy - 21}
                textAnchor="middle"
                fill="#CBD5E1"
                fontSize="11"
                fontFamily="monospace"
              >
                {isAr ? 'شارع عرض 18 م (الواجهة الأمامية)' : '18m ACCESS ROAD (FRONTAGE)'}
              </text>

              {/* Plot Polygon */}
              <polygon
                points={polyStr}
                fill="rgba(180,134,60,0.14)"
                stroke="#D4AF37"
                strokeWidth="2.5"
              />

              {/* Buildable Setback Envelope */}
              {showSetbacks && bx2 > bx1 && by2 > by1 && (
                <>
                  <rect
                    x={bTL.sx}
                    y={bTL.sy}
                    width={bBR.sx - bTL.sx}
                    height={bBR.sy - bTL.sy}
                    fill="rgba(56,189,248,0.12)"
                    stroke="#38BDF8"
                    strokeWidth="2"
                    strokeDasharray="6 4"
                  />
                  <text
                    x={(bTL.sx + bBR.sx) / 2}
                    y={(bTL.sy + bBR.sy) / 2}
                    textAnchor="middle"
                    fill="#E0F2FE"
                    fontSize="12"
                    fontFamily="monospace"
                  >
                    {isAr ? 'النطاق المسموح للبناء' : 'BUILDABLE ENVELOPE'} ({buildableAreaSqM.toFixed(1)} m²)
                  </text>
                </>
              )}

              {/* Vertices & Edge Lengths */}
              {pts.map((pt, idx) => {
                const p1 = toSvg(pt.x, pt.y);
                const next = pts[(idx + 1) % pts.length];
                const p2 = toSvg(next.x, next.y);
                const edgeMeters = Math.hypot(next.x - pt.x, next.y - pt.y).toFixed(2);
                const midX = (p1.sx + p2.sx) / 2;
                const midY = (p1.sy + p2.sy) / 2;
                return (
                  <g key={idx}>
                    <circle cx={p1.sx} cy={p1.sy} r="5" fill="#D4AF37" stroke="#0F172A" strokeWidth="1.5" />
                    <text x={p1.sx + 8} y={p1.sy - 8} fill="#F8FAFC" fontSize="10" fontFamily="monospace">
                      {pt.label || `P${idx + 1}`}
                    </text>
                    {showDimensions && (
                      <text x={midX} y={midY - 6} textAnchor="middle" fill="#FDE68A" fontSize="11" fontFamily="monospace">
                        {edgeMeters} m
                      </text>
                    )}
                  </g>
                );
              })}

              {/* North Arrow */}
              <g transform={`translate(${svgW - 48}, 48)`}>
                <circle r="18" fill="rgba(15,23,42,0.85)" stroke="#475569" strokeWidth="1" />
                <path d="M 0 -12 L 5 6 L 0 2 L -5 6 Z" fill="#D4AF37" />
                <text y="16" textAnchor="middle" fill="#CBD5E1" fontSize="9" fontFamily="monospace">N</text>
              </g>
            </svg>
          </div>
        </Card>

        {/* Plot Telemetry & Setbacks Panel */}
        <div className="xl:col-span-4 space-y-4">
          <Card>
            <CardHeader
              icon={<MapPin className="w-4 h-4" />}
              title={isAr ? 'البيانات المساحية والتنظيمية' : 'Cadastral & Zoning Data'}
            />
            <div className="p-5 space-y-2.5 text-xs">
              <div className="flex justify-between py-1.5 border-b border-[var(--border-hairline)]">
                <span className="text-[var(--text-muted)]">{isAr ? 'الإمارة / القطاع' : 'Emirate / Sector'}</span>
                <span className="font-semibold text-[var(--text-primary)]">{gisData.sectorName}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[var(--border-hairline)]">
                <span className="text-[var(--text-muted)]">{isAr ? 'رقم القطعة / الحوض' : 'Plot / Basin'}</span>
                <span dir="ltr" className="font-mono font-semibold text-[#B4863C]">{gisData.plotNumber} / {gisData.basinNumber}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[var(--border-hairline)]">
                <span className="text-[var(--text-muted)]">{isAr ? 'الإحداثيات WGS84' : 'WGS84 Coordinates'}</span>
                <span dir="ltr" className="font-mono tabular-nums text-[var(--text-primary)]">
                  {gisData.latitude.toFixed(4)}, {gisData.longitude.toFixed(4)}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[var(--border-hairline)]">
                <span className="text-[var(--text-muted)]">{isAr ? 'مساحة الأرض' : 'Total Plot Area'}</span>
                <span dir="ltr" className="font-mono tabular-nums font-semibold text-[var(--text-primary)]">
                  {gisData.plotAreaSqM} m² ({gisData.plotAreaSqFt.toLocaleString()} ft²)
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-[var(--border-hairline)]">
                <span className="text-[var(--text-muted)]">{isAr ? 'نسبة البناء المسموحة' : 'Max Envelope Coverage'}</span>
                <span dir="ltr" className="font-mono tabular-nums font-semibold text-sky-600 dark:text-sky-400">
                  {coveragePct.toFixed(1)}% ({buildableAreaSqM.toFixed(1)} m²)
                </span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[var(--text-muted)]">{isAr ? 'الاستعمال المعتمد' : 'Zoning'}</span>
                <span className="font-medium text-[var(--text-primary)]">{gisData.zoning}</span>
              </div>
            </div>
          </Card>

          <Card>
            <CardHeader
              icon={<Ruler className="w-4 h-4" />}
              title={isAr ? 'تعديل الارتدادات النظامية (م)' : 'Municipal Setbacks (m)'}
            />
            <div className="p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3 text-xs">
                {(['front', 'rear', 'sideLeft', 'sideRight'] as const).map((side) => (
                  <label key={side} className="space-y-1">
                    <span className="text-[var(--text-muted)] capitalize block">{side}</span>
                    <input
                      type="number"
                      step="0.5"
                      min={0}
                      value={gisData.setbacks[side]}
                      onChange={(e) => handleSetbackChange(side, Number(e.target.value))}
                      className="w-full h-8 px-3 rounded-lg border border-[var(--border-hairline)] bg-[var(--bg-surface-subtle)] text-[var(--text-primary)] font-mono tabular-nums"
                    />
                  </label>
                ))}
              </div>

              <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>
                  {isAr
                    ? 'مطابق لاشتراطات الارتداد لدائرة التخطيط والمساحة بالشارقة'
                    : 'Compliant with Sharjah DTPS setback code'}
                </span>
              </div>
            </div>
          </Card>

          <Card padded className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-[var(--text-secondary)]">
              <Layers className="w-4 h-4 text-[#B4863C]" />
              <span>{isAr ? 'مساحة البناء الحالية BUA' : 'Built-Up Area (BUA)'}</span>
            </div>
            <span dir="ltr" className="font-mono tabular-nums font-bold text-[var(--text-primary)]">
              {gisData.builtUpAreaSqFt.toLocaleString()} sq.ft
            </span>
          </Card>
        </div>
      </div>
    </div>
  );
};
